$(function () {
    kendo.culture("pt-BR");

    var painelApp = (function () {
        var loadGridRecursos = function () {

            var dados = [{
                GUIAS: "Mat e med", APRESENTADO: "4", ANALISE: "1",
                FINALIZADO: "3", DEVOLVIDO: "0"
            },
            {
                GUIAS: "Itens", APRESENTADO: "5", ANALISE: "3",
                FINALIZADO: "1", DEVOLVIDO: "1"
            }];

            $("#gridRec").kendoGrid({

                // dataSource = new kendo.data.DataSource({
                //     transport: {
                //         read: {
                //             url: pathRoot + '/FaturamentoTISS/Painel/ResumoDeRecursos?cod_prestador_ts=' + $("#COD_PRESTADOR_TS").val(),
                //             type: "POST",
                //             dataType: "json"
                //         },
                //         parameterMap: function (options, operation) {
                //             if (operation !== "read" && options.models) {
                //                 return { models: kendo.stringify(options.models) };
                //             }
                //         }
                //     },
                //     batch: true,
                //     pageSize: 2,
                //     serverPaging: true,
                //     serverFiltering: true,
                //     serverSorting: true,
                //     aggregate: [{ field: "APRESENTADO", aggregate: "sum", format: "{0:n0}" }, { field: "ANALISE", aggregate: "sum", format: "{0:n0}" }, { field: "FINALIZADO", aggregate: "sum", format: "{0:n0}" }, { field: "DEVOLVIDO", aggregate: "sum", format: "{0:n0}" }],
                //     autoSync: true,
                //     schema: {
                //         model: {
                //             id: "cod_ts_nr",
                //             fields: {
                //                 cod_ts_nr: { editable: false, nullable: true },
                //                 GUIAS: { type: "string" },
                //                 APRESENTADO: { type: "number", validation: { min: 0 } },
                //                 ANALISE: { type: "number", validation: { min: 0 } },
                //                 FINALIZADO: { type: "number", validation: { min: 0 } },
                //                 DEVOLVIDO: { type: "number", validation: { min: 0 } }
                //             }
                //         }
                //     }
                // });

                dataSource: {
                    data: dados,
                    schema: {
                        model: {
                            fields: {
                                GUIAS: { type: "string" },
                                APRESENTADO: { type: "number" },
                                ANALISE: { type: "number" },
                                FINALIZADO: { type: "number" },
                                DEVOLVIDO: { type: "number" }
                            }
                        }
                    },
                    pageSize: 3,
                    serverPaging: true,
                    serverFiltering: true,
                    serverSorting: true,
                    aggregate: [{ field: "APRESENTADO", aggregate: "sum" }, { field: "ANALISE", aggregate: "sum" }, { field: "FINALIZADO", aggregate: "sum" }, { field: "DEVOLVIDO", aggregate: "sum" }],
                },
                columns: [{
                    title: "Resumo de Recursos (últimos 30 dias)",
                    headerAttributes: { style: "text-align: center" },
                    columns: [{
                        field: "GUIAS",
                        title: "Guias",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" },
                        footerTemplate: "Total:"
                    }, {
                        field: "APRESENTADO",
                        aggregates: ["sum"],
                        footerTemplate: "#=sum#",
                        title: "Apresentado",
                        type: "number",
                        format: "{0:n0}",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "ANALISE",
                        aggregates: ["sum"],
                        footerTemplate: "#=sum#",
                        title: "Em Análise",
                        type: "number",
                        format: "{0:n0}",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "FINALIZADO",
                        aggregates: ["sum"],
                        footerTemplate: "#=sum#",
                        title: "Finalizados",
                        type: "number",
                        format: "{0:n0}",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "DEVOLVIDO",
                        aggregates: ["sum"],
                        footerTemplate: "#=sum#",
                        title: "Devolvidos",
                        type: "number",
                        format: "{0:n0}",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }]
                }]

            });
        }

        var loadGridGlosas = function () {
            var dados = [{
                dataPagamento: "14/07/2020", apresentado: "R$ 378.520,88", glosado: "89525,33",
                dataVencimento: "11/11/2020", expira: "54"
            },
            {
                dataPagamento: "14/08/2020", apresentado: "R$ 197.500,23", glosado: "22520,88",
                dataVencimento: "12/12/2020", expira: "116"
            }];

            $("#gridGlo").kendoGrid({

                dataSource: {
                    data: dados,
                    schema: {
                        model: {
                            fields: {
                                dataPagamento: { type: "string" },
                                apresentado: { type: "decimal" },
                                glosado: { type: "number" },
                                dataVencimento: { type: "date" },
                                expira: { type: "number" }
                            }
                        }
                    },
                    pageSize: 3
                },
                columns: [{
                    title: "Glosas a Vencer (para apresentação de Recurso)",
                    headerAttributes: { style: "text-align: center" },
                    columns: [{
                        field: "dataPagamento",
                        title: "Data de Pagamento",
                        format: "{0:dd/MM/yyyy}",
                        width: "120px",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "apresentado",
                        title: "Vlr Apresentado",
                        type: "decimal",
                        format: "{0:c}",
                        width: "100px",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "glosado",
                        title: "Glosado",
                        type: "decimal",
                        format: "{0:n0}",
                        width: "100px",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "dataVencimento",
                        title: "Data Vencimento",
                        format: "{0:dd/MM/yyyy}",
                        width: "100px",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "expira",
                        title: "Expira em",
                        type: "number",
                        format: "{0:n0}",
                        width: "80px",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }]
                }],
            });
        }

        var loadGridRanking = function () {

            // dataSource = new kendo.data.DataSource({
            //     transport: {
            //         read: {
            //             url: pathRoot + '/FaturamentoTISS/Painel/Ranking?cod_prestador_ts=' + $("#COD_PRESTADOR_TS").val(),
            //             type: "POST",
            //             dataType: "json"
            //         },
            //         parameterMap: function (options, operation) {
            //             if (operation !== "read" && options.models) {
            //                 return { models: kendo.stringify(options.models) };
            //             }
            //         }
            //     },
            //     batch: true,
            //     pageSize: 5,
            //     autoSync: true,
            //     schema: {
            //         model: {
            //             id: "cod_motivo_glosa",
            //             fields: {
            //                 cod_motivo_glosa: { editable: false, nullable: true },
            //                 cod_motivo_glosa: { type: "number", validation: { min: 0 } },
            //                 desc_motivo_glosa: { type: "string" },
            //                 qtdade: { type: "number", validation: { min: 0 } }
            //             }
            //         }
            //     }
            // });

            var dados = [{
                cod_motivo_glosa: "1714", desc_motivo_glosa: "Valor do serviço superior ao valor de tabela", qtdade: "500"
            }, {
                cod_motivo_glosa: "1214", desc_motivo_glosa: "Credenciado não habilitado a realizar o", qtdade: "750"
            }, {
                cod_motivo_glosa: "2101", desc_motivo_glosa: "Medicamento inválido", qtdade: "280"
            }, {
                cod_motivo_glosa: "2001", desc_motivo_glosa: "Material inválido", qtdade: "320"
            }, {
                cod_motivo_glosa: "1402", desc_motivo_glosa: "Procedimento não autorizado", qtdade: "430"
            }];


            $("#gridRan").kendoGrid({
                dataSource: {
                    data: dados,
                    schema: {
                        model: {
                            fields: {
                                cod_motivo_glosa: { type: "number" },
                                desc_motivo_glosa: { type: "string" },
                                qtdade: { type: "number" }
                            }
                        }
                    },
                    pageSize: 5
                },
                columns: [{
                    title: "Ranking de Glosas - Top 5",
                    headerAttributes: { style: "text-align: center" },
                    columns: [{
                        field: "cod_motivo_glosa",
                        title: "Código",
                        type: "number",
                        width: "25px",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "desc_motivo_glosa",
                        title: "Descrição da Glosa",
                        width: "100px",
                        attributes: { style: "text-align: left" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }, {
                        field: "qtdade",
                        title: "Qtde Itens",
                        type: "number",
                        format: "{0:n0}",
                        width: "25px",
                        attributes: { style: "text-align: center" },
                        headerAttributes: { style: "text-align: center" },
                        footerAttributes: { style: "text-align: center" }
                    }]
                }]
            });

            //var loadGridRankingChart = function () {
            //    dataSource = new kendo.data.DataSource({
            //        transport: {
            //            read: {
            //                url: pathRoot + '/FaturamentoTISS/Painel/RankingChart?cod_prestador_ts=' + $("#COD_PRESTADOR_TS").val(),
            //                type: "POST",
            //                dataType: "json"
            //            },
            //            parameterMap: function (options, operation) {
            //                if (operation !== "read" && options.models) {
            //                    return { models: kendo.stringify(options.models) };
            //                }
            //            }
            //        },
            //        batch: true,
            //        autoSync: true,
            //        schema: {
            //            model: {
            //                id: "cod_motivo_glosa",
            //                fields: {
            //                    cod_motivo_glosa: { editable: false, nullable: true },
            //                    cod_motivo_glosa: { type: "number", validation: { min: 1 } },
            //                    qtdade: { type: "number", validation: { min: 1 } }
            //                }
            //            }
            //        }
            //    });

                
            //}

            $("#gridCha").kendoChart({
                dataSource: dados,
                title: {
                    text: "Ranking de Glosas - Top 5"
                },
                legend: {
                    position: "top"
                },
                series: [{
                    field: "qtdade",
                    categoryField: "cod_motivo_glosa",
                    color: "blue",
                    opacity: 0.9,
                    name: "Código"
                }],
                categoryAxis: {
                    majorGridLines: {
                        visible: false
                    }
                },
                valueAxis: {
                    labels: {
                        format: "{0}"
                    },
                    line: {
                        visible: false
                    },
                    axisCrossingValue: 0
                },
                tooltip: {
                    visible: true,
                    format: "{0}%",
                    template: "#= value #"
                }
            });
        }
        return {
            iniciar: function () {
                loadGridRecursos();
                loadGridGlosas();
                loadGridRanking();
            },
            recriar: function () {
                loadGridRecursos();
                loadGridGlosas();
                loadGridRanking();
            }
        }
    }());

    painelApp.iniciar();

    setInterval(function () {

        painelApp.iniciar();
        console.log("reiniciado");

    }, 10000);

    intervalo = setInterval(function () {

        clearInterval(intervalo);
        console.log("clear ok");

    }, 1000);

    $(window).on("resize", function () {
        $(document).bind("kendo:skinChange", painelApp.recriar);
        console.log("recriar");
    });
});